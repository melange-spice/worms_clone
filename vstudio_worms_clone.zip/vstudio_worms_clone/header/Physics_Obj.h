#pragma once
#include "raylib.h"

class Physics_Obj
{
protected:
    Vector2 position;
    Vector2 velocity;
    Vector2 acceleration;

    float radius;
    bool is_stable;

public:
    Physics_Obj(Vector2 position, float radius, Vector2 velocity = { 0, 0 }, Vector2 acceleration = { 0, 0 });

    virtual void draw() const = 0;
    void update_position(Vector2 position);

    virtual ~Physics_Obj() = default;
};


Physics_Obj::Physics_Obj(Vector2 position, float radius, Vector2 velocity, Vector2 acceleration) : position{ position }, radius{ radius }, velocity{ velocity }, acceleration{ acceleration }, is_stable{ false }
{
}

void Physics_Obj::update_position(Vector2 position) {
    this->position = position;
}
